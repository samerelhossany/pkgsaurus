#include "kernel/types.h"
#include "kernel/fcntl.h"
#include "user/user.h"


int main(int argc, char* argv)
{

int fd[2];
pipe(fd);
int fd1[2];
pipe(fd1);
char buf[512];
char buf2[512];
char msg[512];

read(0,msg,sizeof(msg));


write(fd[1],msg,strlen(msg));
read(fd[0],buf,strlen(msg));

write(fd1[1],buf,strlen(msg));
read(fd1[0],buf2,strlen(msg));

write(1,buf2,strlen(msg));

exit(0);
}
