#include "kernel/types.h"
#include "user/user.h"
int main()
{
int pid;

pid = fork();
printf("fork() returned %d\n",pid);
printf("%s",(pid == 0?"child\n":"parent\n"));  
exit(0);
return 0;
}

