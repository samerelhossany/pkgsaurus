#include "kernel/types.h"
#include "kernel/fcntl.h"
#include "user/user.h"
#include "kernel/stat.h"

#define EOF_MARKER "__EOF__"
#define EOF_LEN 7

int ends_with_eof(char *buf, int n) {
    // Check if the buffer ends with __EOF__
    if (n < EOF_LEN) return 0;
    return memcmp(buf + n - EOF_LEN, EOF_MARKER, EOF_LEN) == 0;
}

int main(int argc, char *argv[]) {
    if (argc < 2) {
        fprintf(2, "Usage: recv <outputfile>\n");
        exit(1);
    }

    int outfd = open(argv[1], O_CREATE | O_WRONLY);
    if (outfd < 0) {
        fprintf(2, "Failed to open output file\n");
        exit(1);
    }

    char buf[512];
    int n;
    while ((n = read(0, buf, sizeof(buf))) > 0) {
        // Check if this chunk ends with the EOF marker
        if (ends_with_eof(buf, n)) {
            // Write only the content before the marker
            write(outfd, buf, n - EOF_LEN);
            break;
        }
        write(outfd, buf, n);
    }

    close(outfd);
    exit(0);
}

