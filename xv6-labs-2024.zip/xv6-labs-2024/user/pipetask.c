#include "kernel/types.h"
#include "user/user.h"

char* msg1 = "\033[31;42;1mhello, world #1\033[0m"; 
char* msg2 = "\033[33;41;1mhello, world #2\033[0m"; 
char* msg3 = "\033[35;44;1mhello, world #3\033[0m"; 

int main() { 
    char inbuf[16]; 
    int fds[2], i; 
    pipe(fds);

    
    write(fds[1], msg1, 16); 
    write(fds[1], msg2, 16); 
    write(fds[1], msg3, 16); 

   
    for (i = 0; i < 3; i++) { 
        read(fds[0], inbuf, 16); 
        printf("%s\n", inbuf); 
    } 

  
    close(fds[0]); 
    close(fds[1]); 

    return 0; 
}
