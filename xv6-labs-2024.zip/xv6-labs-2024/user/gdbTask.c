#include"kernel/types.h" 
#include"user/user.h"
int main(){
printf("the program is running\n");
sleep(100);
printf("the program is finished\n");
exit(0);
}
