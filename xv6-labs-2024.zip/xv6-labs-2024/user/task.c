#include "kernel/types.h"
#include "user/user.h"

int main() {
    int fds[2]; 
    char buf[100];
    pipe(fds); 

    int pid = fork(); 

    if (pid > 0) {  
        write(fds[1], "Message from parent\n", 20);
        close(fds[1]); 
    } 
    else if (pid == 0) {  
        write(fds[1], "Message from child\n", 19);
        close(fds[1]);
    }

    int n = read(fds[0], buf, sizeof(buf));
    write(1, buf, n);

    close(fds[0]);
    exit(0);
}
