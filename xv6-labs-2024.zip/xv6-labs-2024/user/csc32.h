#ifndef CRC32_H
#define CRC32_H

unsigned int crc32(const unsigned char *data, int len);

#endif

