#include "kernel/types.h"
#include "user/user.h"

int main(int argc, char*  argv[] )
{

if((argc !=2) && (argv[1]>0)){
    printf("something is wrong here. enter a proper input!!!!!!!!");
    exit(1);}
    else{
printf("\033[33;1mThe program that was created by me, \033[31;1mSamer Elhossany and my id is 221001697\033[33;1m will run for %s so stay tuned and \033[44;1mchill out\033[0m\n\n",argv[1]);
sleep(atoi(argv[1]));
printf("\033[31;1mhere you go buddy !!!\033[0m\n\n");
exit(0);
}
}
