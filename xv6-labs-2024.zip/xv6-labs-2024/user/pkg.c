// user/pkg.c
#include "kernel/types.h"
#include "user/user.h"
#include "kernel/fcntl.h"

#define UART 0 // stdin is UART if using `-serial stdio` or `-serial pty`

int main(int argc, char *argv[]) {
    if (argc != 2) {
        printf("Usage: pkg filename\n");
        exit(1);
    }

    char *filename = argv[1];
    int fd = open(filename, O_CREATE | O_WRONLY);
    if (fd < 0) {
        printf("Could not create %s\n", filename);
        exit(1);
    }

    int size;
    if (read(UART, &size, sizeof(int)) != sizeof(int)) {
        printf("Failed to read size\n");
        close(fd);
        exit(1);
    }

    char buf[512];
    int received = 0;
    while (received < size) {
        int n = read(UART, buf, sizeof(buf));
        if (n <= 0) break;
        write(fd, buf, n);
        received += n;
    }

    close(fd);
    printf("Received %s (%d bytes)\n", filename, received);
    exit(0);
}

