#include "kernel/types.h"
#include "user/user.h"
#include "kernel/fcntl.h"

int main()
{

for(int i=0;i<10;i++)
{

printf("%d\n",i+1);

}


return 0;
}
