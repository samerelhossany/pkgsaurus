#include "kernel/types.h"
#include "kernel/fcntl.h"

#include "user/user.h"

int main(int argc, char* argv[])
{

if(argc != 2)
{
printf("error\n");
exit(1);
}
if(argv<=0)
{

printf("must be positive\n");
}
sleep(atoi(argv[1]));
printf("finished for %s\n",argv[1]);
exit(0);
}
