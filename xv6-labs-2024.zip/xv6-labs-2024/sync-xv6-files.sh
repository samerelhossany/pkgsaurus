#!/bin/bash

# Folder where your shared files are
SHARED_FOLDER=~/xv6_shared_dir

# Path to your fs.img file
FS_IMG=fs.img

# Check if mcopy is installed
if ! command -v mcopy &> /dev/null; then
    echo "❌ mcopy (mtools) not found. Run: sudo apt install mtools"
    exit 1
fi

# Copy each file into the fs.img root
for file in "$SHARED_FOLDER"/*; do
    echo "📦 Copying $(basename "$file") into fs.img..."
    mcopy -o -i "$FS_IMG" "$file" ::/
done

# Run xv6
make qemu
