// pm_server.c - Package Manager Server for Ubuntu host
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <fcntl.h>
#include <errno.h>
#include <sys/socket.h>
#include <sys/un.h>
#include <sys/stat.h>
#include <dirent.h>

#define SOCKET_PATH "/tmp/xv6_pm_socket"
#define PACKAGE_DIR "/home/yourusername/xv6_packages"  // Change this to your actual path
#define MAX_BUF 1024

typedef struct {
    char name[256];
    char path[512];
    size_t size;
} package_t;

// Global variables
package_t *packages = NULL;
int package_count = 0;

// Function prototypes
void load_packages();
void handle_client(int client_fd);
void handle_install(int client_fd, const char *package_name);
void handle_list(int client_fd);
void free_packages();

int main() {
    int server_fd, client_fd;
    struct sockaddr_un server_addr, client_addr;
    socklen_t client_len;

    // Load available packages
    load_packages();

    // Create socket
    server_fd = socket(AF_UNIX, SOCK_STREAM, 0);
    if (server_fd < 0) {
        perror("socket failed");
        exit(EXIT_FAILURE);
    }

    // Setup server address
    memset(&server_addr, 0, sizeof(server_addr));
    server_addr.sun_family = AF_UNIX;
    strncpy(server_addr.sun_path, SOCKET_PATH, sizeof(server_addr.sun_path) - 1);

    // Remove socket file if it already exists
    unlink(SOCKET_PATH);

    // Bind socket
    if (bind(server_fd, (struct sockaddr *)&server_addr, sizeof(server_addr)) < 0) {
        perror("bind failed");
        close(server_fd);
        exit(EXIT_FAILURE);
    }

    // Listen for connections
    if (listen(server_fd, 5) < 0) {
        perror("listen failed");
        close(server_fd);
        exit(EXIT_FAILURE);
    }

    printf("Server listening on %s\n", SOCKET_PATH);

    while (1) {
        // Accept client connection
        client_len = sizeof(client_addr);
        client_fd = accept(server_fd, (struct sockaddr *)&client_addr, &client_len);
        if (client_fd < 0) {
            perror("accept failed");
            continue;
        }

        printf("Client connected\n");
        handle_client(client_fd);
        close(client_fd);
    }

    // Cleanup
    close(server_fd);
    free_packages();
    unlink(SOCKET_PATH);
    return 0;
}

void load_packages() {
    DIR *dir;
    struct dirent *entry;
    struct stat file_stat;
    char filepath[512];

    // Open package directory
    dir = opendir(PACKAGE_DIR);
    if (!dir) {
        perror("Failed to open package directory");
        exit(EXIT_FAILURE);
    }

    // Count number of files
    package_count = 0;
    while ((entry = readdir(dir)) != NULL) {
        if (entry->d_type == DT_REG) { // Regular file
            package_count++;
        }
    }

    // Allocate memory for packages
    packages = malloc(package_count * sizeof(package_t));
    if (!packages) {
        perror("Memory allocation failed");
        closedir(dir);
        exit(EXIT_FAILURE);
    }

    // Load package information
    rewinddir(dir);
    int i = 0;
    while ((entry = readdir(dir)) != NULL && i < package_count) {
        if (entry->d_type == DT_REG) { // Regular file
            snprintf(filepath, sizeof(filepath), "%s/%s", PACKAGE_DIR, entry->d_name);
            
            // Get file information
            if (stat(filepath, &file_stat) == 0) {
                strncpy(packages[i].name, entry->d_name, sizeof(packages[i].name) - 1);
                strncpy(packages[i].path, filepath, sizeof(packages[i].path) - 1);
                packages[i].size = file_stat.st_size;
                
                printf("Found package: %s (%zu bytes)\n", packages[i].name, packages[i].size);
                i++;
            }
        }
    }

    // Update actual package count
    package_count = i;
    closedir(dir);
    
    printf("Loaded %d packages\n", package_count);
}

void free_packages() {
    if (packages) {
        free(packages);
        packages = NULL;
    }
    package_count = 0;
}

void handle_client(int client_fd) {
    char buffer[MAX_BUF];
    ssize_t n;
    
    while (1) {
        // Clear buffer
        memset(buffer, 0, sizeof(buffer));
        
        // Read from client
        n = read(client_fd, buffer, sizeof(buffer) - 1);
        if (n <= 0) {
            if (n < 0) perror("read failed");
            break;
        }
        
        // Ensure null termination
        buffer[n] = '\0';
        
        // Find newline
        char *newline = strchr(buffer, '\n');
        if (newline) *newline = '\0';
        
        printf("Received command: %s\n", buffer);
        
        // Process command
        if (strncmp(buffer, "INSTALL ", 8) == 0) {
            handle_install(client_fd, buffer + 8);
        } else if (strcmp(buffer, "LIST") == 0) {
            handle_list(client_fd);
        } else if (strcmp(buffer, "ACK") == 0) {
            printf("Client acknowledged package receipt\n");
        } else {
            const char *error_msg = "ERROR Unknown command\n";
            write(client_fd, error_msg, strlen(error_msg));
        }
    }
    
    printf("Client disconnected\n");
}

void handle_install(int client_fd, const char *package_name) {
    printf("Install request for package: %s\n", package_name);
    
    // Find requested package
    int i;
    for (i = 0; i < package_count; i++) {
        if (strcmp(packages[i].name, package_name) == 0) {
            break;
        }
    }
    
    // Check if package exists
    if (i >= package_count) {
        char error_msg[MAX_BUF];
        snprintf(error_msg, sizeof(error_msg), "ERROR Package not found: %s\n", package_name);
        write(client_fd, error_msg, strlen(error_msg));
        return;
    }
    
    // Open package file
    int fd = open(packages[i].path, O_RDONLY);
    if (fd < 0) {
        char error_msg[MAX_BUF];
        snprintf(error_msg, sizeof(error_msg), "ERROR Failed to open package: %s\n", package_name);
        write(client_fd, error_msg, strlen(error_msg));
        return;
    }
    
    // Send package header
    char header[MAX_BUF];
    snprintf(header, sizeof(header), "SENDING %zu\n", packages[i].size);
    write(client_fd, header, strlen(header));
    
    // Small delay to ensure xv6 has time to process
    usleep(100000);  // 100ms
    
    // Send package data
    char data_buf[MAX_BUF];
    ssize_t bytes_read;
    size_t total_sent = 0;
    
    while ((bytes_read = read(fd, data_buf, sizeof(data_buf))) > 0) {
        ssize_t bytes_written = write(client_fd, data_buf, bytes_read);
        if (bytes_written < 0) {
            perror("write failed");
            close(fd);
            return;
        }
        total_sent += bytes_written;
    }
    
    close(fd);
    printf("Sent package %s (%zu bytes)\n", package_name, total_sent);
}

void handle_list(int client_fd) {
    printf("List request\n");
    
    if (package_count == 0) {
        const char *msg = "No packages available\n";
        write(client_fd, msg, strlen(msg));
    } else {
        char list_item[MAX_BUF];
        
        for (int i = 0; i < package_count; i++) {
            snprintf(list_item, sizeof(list_item), "%s (%zu bytes)\n", 
                    packages[i].name, packages[i].size);
            write(client_fd, list_item, strlen(list_item));
            usleep(10000);  // 10ms delay between packages
        }
    }
    
    // Send end marker
    write(client_fd, "END\n", 4);
}
